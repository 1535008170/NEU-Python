from django.shortcuts import render
from django.http import JsonResponse

city_list=['北京','上海','天津','重庆','哈尔滨','长春','沈阳','呼和浩特','石家庄','乌鲁木齐','兰州','西宁','西安','银川','郑州','济南','太原','合肥','长沙','武汉','南京','成都','贵阳','昆明','南宁','拉萨','杭州','南昌','广州','福州','台北','海口','香港','澳门']

def chart_bar(request):
    """ 构造柱状图数据 或者也可以在数据库获取 """
    legend = ["城市名"]
    series_list = [
        {
            "name": '城市名',
            "type": 'bar',
            "barWidth":'50%',
            "data": [76598, 98798, 36432, 50432, 21412, 12548, 22498, 93275, 10124, 53252],
            "showBackground": 'true',
            
        }
    ]
    x_axis = ['北京','上海','天津','重庆','哈尔滨','长春','沈阳','呼和浩特','石家庄','南京']

    result = {
        "status": True,
        "data": {
            'legend': legend,
            'series_list': series_list,
            'x_axis': x_axis,
        }
    }
    return JsonResponse(result)

def chart_line(request):
    legend = ["上海", "北京", "沈阳"]
    series_list = [
        {
            "name": '上海',
            "type": 'line',
            "stack": 'Total',
            "data": [16879, 27492, 36291, 56231, 27638, 13623]
        },
        {
            "name": '北京',
            "type": 'line',
            "stack": 'Total',
            "data": [27394, 12834, 63313, 43312, 21234, 51234]
        },
        {
            "name": '沈阳',
            "type": 'line',
            "stack": 'Total',
            "data": [75432, 34289, 12453, 42345, 21423, 54234]
        }
    ]
    x_axis = ['7月', '8月', '9月', '10月', '11月', '12月']

    result = {
        "status": True,
        "data": {
            'legend': legend,
            'series_list': series_list,
            'x_axis': x_axis,
        }
    }
    return JsonResponse(result)

def chart_pie(request):
    """ 构造饼图的数据 """

    db_data_list = [
        {"value": 2048, "name": '板楼'},
        {"value": 1735, "name": '塔楼'},
        {"value": 580, "name": '板塔结合'},
    ]

    result = {
        "status": True,
        "data": db_data_list
    }
    return JsonResponse(result)

def chart_update(request):
    """ 构造柱状图数据 或者也可以在数据库获取 """
    legend = ["城市名"]
    series_list = [
        {
            "name": '城市名',
            "type": 'bar',
            "barWidth":'50%',
            "data": [76603, 98803, 36432, 50432, 21412, 12548, 22498, 93275, 10124, 53252],
            "showBackground": 'true',
            
        }
    ]
    x_axis = ['北京','上海','天津','重庆','哈尔滨','长春','沈阳','呼和浩特','石家庄','南京']

    result = {
        "status": True,
        "data": {
            'legend': legend,
            'series_list': series_list,
            'x_axis': x_axis,
        }
    }
    return JsonResponse(result)