import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.neural_network import MLPRegressor
import joblib

data = pd.read_excel("sy.xlsx")

le = LabelEncoder()
scaler = StandardScaler()

le.fit(data['position'])
data['position_encoded'] = le.transform(data['position'])
#print(data['position_encoded']) 

le.fit(data['totalPrice'])
data['totalPrice_encoded'] = le.transform(data['totalPrice'])

#print(data)
''' 把数据去重一下 看看他帮我们赋值的结果 '''
#data.drop_duplicates(subset=['position_encoded'], keep='first', inplace=True)
#print(data[['position', 'position_encoded']])

X = data[['houseType','area','position_encoded']]
y = data['totalPrice_encoded']
X = scaler.fit_transform(X)

#模型训练
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.05)

model = MLPRegressor(
                    hidden_layer_sizes=(9,18,36,72,36,72,36,18,9),
                    max_iter=5000,
                    learning_rate_init=0.005,
                    learning_rate='adaptive')

model.fit(X_train,y_train)

joblib.dump(model, 'MLP.joblib')

# model = joblib.load('model.pkl')
predictions = model.predict(X_test)

accuracy = model.score(X_test,y_test)

print("准确率：",accuracy)

