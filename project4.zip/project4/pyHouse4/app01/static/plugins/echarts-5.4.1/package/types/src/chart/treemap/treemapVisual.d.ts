import TreemapSeriesModel from './TreemapSeries.js';
declare const _default: {
    seriesType: string;
    reset(seriesModel: TreemapSeriesModel): void;
};
export default _default;
