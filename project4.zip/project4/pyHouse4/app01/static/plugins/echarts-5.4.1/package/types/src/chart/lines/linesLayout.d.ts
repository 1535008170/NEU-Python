import { StageHandler } from '../../util/types.js';
declare const linesLayout: StageHandler;
export default linesLayout;
