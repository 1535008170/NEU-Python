import { GeoJSONRegion } from '../Region.js';
export default function fixDiaoyuIsland(mapType: string, region: GeoJSONRegion): void;
