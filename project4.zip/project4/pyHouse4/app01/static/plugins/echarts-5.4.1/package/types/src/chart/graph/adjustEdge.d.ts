import Graph from '../../data/Graph.js';
export default function adjustEdge(graph: Graph, scale: number): void;
