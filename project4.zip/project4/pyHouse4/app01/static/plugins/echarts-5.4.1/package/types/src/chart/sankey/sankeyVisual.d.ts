import GlobalModel from '../../model/Global.js';
export default function sankeyVisual(ecModel: GlobalModel): void;
