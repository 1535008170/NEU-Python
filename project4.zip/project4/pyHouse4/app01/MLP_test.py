import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.neural_network import MLPRegressor
import joblib

model = joblib.load("C:/Users/86183/Desktop/pyHouse4/app01/MLP.joblib")

dic = {
            '于洪':0,
            '和平':1,
            '大东':2,
            '康平县':3,
            '新民市':4,
            '望花区':5,
            '沈北新区':6,
            '沈河':7,
            '法库县':8,
            '浑南':9,
            '皇姑':10,
            '苏家屯':11,
            '辽中区':12,
            '铁西':13
    }

info1 = {
        'houseType':"5室5厅",
        'area':"300平方",
        'position_encoded':dic.get("和平")
    }

info = pd.DataFrame(info1,index=[0])

info['houseType'] = info['houseType'].str.replace('室', '')
info['houseType'] = info['houseType'].str.replace('厅', '')
info['area'] = info['area'].str.replace('平方', '')

scaler = StandardScaler()

prediction = model.predict(info)
#print(prediction)
prediction = int(prediction[0])
print(prediction)