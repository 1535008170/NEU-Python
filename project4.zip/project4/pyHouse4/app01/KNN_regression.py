import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn import neighbors
import numpy as np
import joblib

data = pd.read_excel("sy.xlsx")

le = LabelEncoder()
scaler = StandardScaler()

le.fit(data['position'])
data['position_encoded'] = le.transform(data['position'])
#print(data['position_encoded']) 

le.fit(data['totalPrice'])
data['totalPrice_encoded'] = le.transform(data['totalPrice'])

#print(data)
''' 把数据去重一下 看看他帮我们赋值的结果 '''
#data.drop_duplicates(subset=['position_encoded'], keep='first', inplace=True)
#print(data[['position', 'position_encoded']])

X = data[['houseType','area','position_encoded']]
y = data['totalPrice_encoded']
X = scaler.fit_transform(X)

data = data[['houseType','area','position_encoded']]

model = neighbors.KNeighborsRegressor(n_neighbors=5)
model.fit(X, y)

joblib.dump(model, 'KNN.joblib')

new = np.array([22,155,2]).reshape(1, -1)
new_data = pd.DataFrame(new,columns=['A', 'B', 'C'])
new_data = scaler.fit_transform(new_data)
similar_houses = model.kneighbors(new_data, n_neighbors=5, return_distance=False)

print(similar_houses)

similar_houses = [x for sublist in similar_houses for x in sublist]
print(similar_houses)

data = pd.read_excel("SYdata.xlsx")
"""
print(data.iloc[similar_houses[0]])
print(data.iloc[similar_houses[1]])
print(data.iloc[similar_houses[2]])
print(data.iloc[similar_houses[3]])
print(data.iloc[similar_houses[4]])
"""
data_re = data.loc[[similar_houses[0], similar_houses[1],similar_houses[2],similar_houses[3],similar_houses[4]]]
data_re_arr = np.array(data_re)
print(data_re_arr)
