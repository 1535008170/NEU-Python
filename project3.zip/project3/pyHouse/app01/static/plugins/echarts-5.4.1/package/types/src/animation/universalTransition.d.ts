import { EChartsExtensionInstallRegisters } from '../extension.js';
export declare function installUniversalTransition(registers: EChartsExtensionInstallRegisters): void;
