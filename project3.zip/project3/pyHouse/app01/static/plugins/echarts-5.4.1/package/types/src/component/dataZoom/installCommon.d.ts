import { EChartsExtensionInstallRegisters } from '../../extension.js';
export default function installCommon(registers: EChartsExtensionInstallRegisters): void;
