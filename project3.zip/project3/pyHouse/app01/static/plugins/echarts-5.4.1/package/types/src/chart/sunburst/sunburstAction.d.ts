import { EChartsExtensionInstallRegisters } from '../../extension.js';
export declare const ROOT_TO_NODE_ACTION = "sunburstRootToNode";
export declare function installSunburstAction(registers: EChartsExtensionInstallRegisters): void;
