import { ECUnitOption, AriaOptionMixin } from '../../util/types.js';
export default function ariaPreprocessor(option: ECUnitOption & AriaOptionMixin): void;
